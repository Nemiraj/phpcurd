<?php

class JSONDatabase {
    private $dataFile;
    private $data;
    
    public function __construct($filename = 'data/records.json') {
        $this->dataFile = $filename;
        $this->ensureDataDirectory();
        $this->loadData();
    }
    
    /**
     * Ensure the data directory exists
     */
    private function ensureDataDirectory() {
        $dir = dirname($this->dataFile);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }
    
    /**
     * Load data from JSON file
     */
    private function loadData() {
        if (!file_exists($this->dataFile)) {
            $this->data = [];
            $this->saveData();
        } else {
            $content = file_get_contents($this->dataFile);
            $this->data = json_decode($content, true) ?: [];
        }
    }
    
    /**
     * Save data to JSON file
     */
    private function saveData() {
        $jsonData = json_encode($this->data, JSON_PRETTY_PRINT);
        if ($jsonData === false) {
            error_log('Failed to encode data to JSON');
            return false;
        }
        
        $result = file_put_contents($this->dataFile, $jsonData, LOCK_EX);
        if ($result === false) {
            error_log('Failed to write data to file: ' . $this->dataFile);
            return false;
        }
        
        return true;
    }
    
    /**
     * Generate next available ID
     */
    private function getNextId() {
        if (empty($this->data)) {
            return 1;
        }
        
        $ids = array_column($this->data, 'id');
        return max($ids) + 1;
    }
    
    /**
     * Create a new record
     */
    public function create($data) {
        try {
            $data['id'] = $this->getNextId();
            $this->data[] = $data;
            return $this->saveData() ? $data['id'] : false;
        } catch (Exception $e) {
            error_log('Error creating record: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Read a specific record by ID
     */
    public function read($id) {
        foreach ($this->data as $record) {
            if ($record['id'] == $id) {
                return $record;
            }
        }
        return null;
    }
    
    /**
     * Read all records
     */
    public function readAll() {
        return $this->data;
    }
    
    /**
     * Update a record by ID
     */
    public function update($id, $newData) {
        try {
            foreach ($this->data as $index => $record) {
                if ($record['id'] == $id) {
                    // Preserve the original ID and creation date
                    $newData['id'] = $record['id'];
                    if (isset($record['created_at'])) {
                        $newData['created_at'] = $record['created_at'];
                    }
                    
                    $this->data[$index] = $newData;
                    return $this->saveData();
                }
            }
            return false; // Record not found
        } catch (Exception $e) {
            error_log('Error updating record: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Delete a record by ID
     */
    public function delete($id) {
        try {
            $originalCount = count($this->data);
            $this->data = array_filter($this->data, function($record) use ($id) {
                return $record['id'] != $id;
            });
            
            // Re-index the array to maintain proper structure
            $this->data = array_values($this->data);
            
            if (count($this->data) < $originalCount) {
                return $this->saveData();
            }
            
            return false; // Record not found
        } catch (Exception $e) {
            error_log('Error deleting record: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Search records by field and value
     */
    public function search($field, $value) {
        $results = [];
        foreach ($this->data as $record) {
            if (isset($record[$field]) && stripos($record[$field], $value) !== false) {
                $results[] = $record;
            }
        }
        return $results;
    }
    
    /**
     * Get total count of records
     */
    public function count() {
        return count($this->data);
    }
}
