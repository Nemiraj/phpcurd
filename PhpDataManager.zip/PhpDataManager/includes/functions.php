<?php

/**
 * Sanitize input data
 */
function sanitizeInput($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    return $input;
}

/**
 * Validate record data
 */
function validateRecord($name, $email, $phone) {
    $errors = [];
    
    // Validate name
    if (empty($name)) {
        $errors[] = 'Name is required.';
    } elseif (strlen($name) < 2) {
        $errors[] = 'Name must be at least 2 characters long.';
    } elseif (strlen($name) > 100) {
        $errors[] = 'Name must not exceed 100 characters.';
    } elseif (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
        $errors[] = 'Name should only contain letters and spaces.';
    }
    
    // Validate email
    if (empty($email)) {
        $errors[] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    } elseif (strlen($email) > 255) {
        $errors[] = 'Email must not exceed 255 characters.';
    }
    
    // Validate phone
    if (empty($phone)) {
        $errors[] = 'Phone number is required.';
    } elseif (!preg_match('/^[\+]?[0-9\s\-\(\)]+$/', $phone)) {
        $errors[] = 'Please enter a valid phone number.';
    } elseif (strlen(preg_replace('/[^0-9]/', '', $phone)) < 10) {
        $errors[] = 'Phone number must contain at least 10 digits.';
    }
    
    return $errors;
}

/**
 * Format phone number for display
 */
function formatPhone($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    if (strlen($phone) == 10) {
        return sprintf('(%s) %s-%s', 
            substr($phone, 0, 3),
            substr($phone, 3, 3),
            substr($phone, 6, 4)
        );
    }
    
    return $phone;
}

/**
 * Generate a random color for avatars
 */
function getAvatarColor($name) {
    $colors = [
        '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
        '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9'
    ];
    
    $index = abs(crc32($name)) % count($colors);
    return $colors[$index];
}

/**
 * Get initials from name
 */
function getInitials($name) {
    $words = explode(' ', trim($name));
    $initials = '';
    
    foreach ($words as $word) {
        if (!empty($word)) {
            $initials .= strtoupper(substr($word, 0, 1));
        }
    }
    
    return substr($initials, 0, 2);
}

/**
 * Check if email already exists (for validation)
 */
function emailExists($email, $excludeId = null) {
    global $db;
    $records = $db->readAll();
    
    foreach ($records as $record) {
        if ($record['email'] === $email && $record['id'] != $excludeId) {
            return true;
        }
    }
    
    return false;
}

/**
 * Escape output for HTML display
 */
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Format date for display
 */
function formatDate($date, $format = 'M j, Y g:i A') {
    if (empty($date)) {
        return 'N/A';
    }
    
    try {
        $dateTime = new DateTime($date);
        return $dateTime->format($format);
    } catch (Exception $e) {
        return $date;
    }
}

/**
 * Generate breadcrumb navigation
 */
function generateBreadcrumb($currentView) {
    $breadcrumbs = [
        'list' => 'All Records',
        'create' => 'Add New Record',
        'edit' => 'Edit Record'
    ];
    
    $html = '<nav aria-label="breadcrumb"><ol class="breadcrumb">';
    $html .= '<li class="breadcrumb-item"><a href="index.php">Home</a></li>';
    
    if (isset($breadcrumbs[$currentView])) {
        $html .= '<li class="breadcrumb-item active" aria-current="page">' . $breadcrumbs[$currentView] . '</li>';
    }
    
    $html .= '</ol></nav>';
    return $html;
}

/**
 * Log application errors
 */
function logError($message, $context = []) {
    $logMessage = date('Y-m-d H:i:s') . ' - ' . $message;
    if (!empty($context)) {
        $logMessage .= ' - Context: ' . json_encode($context);
    }
    error_log($logMessage);
}
