<?php
require_once 'includes/database.php';
require_once 'includes/functions.php';

// Initialize database
$db = new JSONDatabase();

// Handle form submissions
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'create':
            $name = sanitizeInput($_POST['name'] ?? '');
            $email = sanitizeInput($_POST['email'] ?? '');
            $phone = sanitizeInput($_POST['phone'] ?? '');
            
            $errors = validateRecord($name, $email, $phone);
            
            if (empty($errors)) {
                $result = $db->create([
                    'name' => $name,
                    'email' => $email,
                    'phone' => $phone,
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                
                if ($result) {
                    $message = 'Record created successfully!';
                    $messageType = 'success';
                } else {
                    $message = 'Error creating record. Please try again.';
                    $messageType = 'danger';
                }
            } else {
                $message = implode('<br>', $errors);
                $messageType = 'danger';
            }
            break;
            
        case 'update':
            $id = (int)($_POST['id'] ?? 0);
            $name = sanitizeInput($_POST['name'] ?? '');
            $email = sanitizeInput($_POST['email'] ?? '');
            $phone = sanitizeInput($_POST['phone'] ?? '');
            
            $errors = validateRecord($name, $email, $phone);
            
            if (empty($errors)) {
                $result = $db->update($id, [
                    'name' => $name,
                    'email' => $email,
                    'phone' => $phone,
                    'updated_at' => date('Y-m-d H:i:s')
                ]);
                
                if ($result) {
                    $message = 'Record updated successfully!';
                    $messageType = 'success';
                } else {
                    $message = 'Error updating record. Record may not exist.';
                    $messageType = 'danger';
                }
            } else {
                $message = implode('<br>', $errors);
                $messageType = 'danger';
            }
            break;
            
        case 'delete':
            $id = (int)($_POST['id'] ?? 0);
            $result = $db->delete($id);
            
            if ($result) {
                $message = 'Record deleted successfully!';
                $messageType = 'success';
            } else {
                $message = 'Error deleting record. Record may not exist.';
                $messageType = 'danger';
            }
            break;
    }
}

// Get current view
$view = $_GET['view'] ?? 'list';
$editId = $_GET['edit'] ?? null;

// Get all records for listing
$records = $db->readAll();

// Get specific record for editing
$editRecord = null;
if ($editId && $view === 'edit') {
    $editRecord = $db->read((int)$editId);
    if (!$editRecord) {
        $message = 'Record not found.';
        $messageType = 'danger';
        $view = 'list';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP CRUD Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-database me-2"></i>
                PHP CRUD App
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link <?= $view === 'list' ? 'active' : '' ?>" href="index.php?view=list">
                    <i class="fas fa-list me-1"></i>View Records
                </a>
                <a class="nav-link <?= $view === 'create' ? 'active' : '' ?>" href="index.php?view=create">
                    <i class="fas fa-plus me-1"></i>Add Record
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if ($message): ?>
            <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
                <?= $message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($view === 'list'): ?>
            <!-- List View -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-list me-2"></i>All Records</h2>
                <a href="index.php?view=create" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i>Add New Record
                </a>
            </div>

            <?php if (empty($records)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">No records found</h4>
                    <p class="text-muted">Start by adding your first record.</p>
                    <a href="index.php?view=create" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i>Add First Record
                    </a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($records as $record): ?>
                                <tr>
                                    <td><?= htmlspecialchars($record['id']) ?></td>
                                    <td><?= htmlspecialchars($record['name']) ?></td>
                                    <td><?= htmlspecialchars($record['email']) ?></td>
                                    <td><?= htmlspecialchars($record['phone']) ?></td>
                                    <td><?= htmlspecialchars($record['created_at'] ?? 'N/A') ?></td>
                                    <td>
                                        <a href="index.php?view=edit&edit=<?= $record['id'] ?>" 
                                           class="btn btn-sm btn-outline-primary me-1">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <button type="button" 
                                                class="btn btn-sm btn-outline-danger"
                                                onclick="confirmDelete(<?= $record['id'] ?>, '<?= htmlspecialchars($record['name']) ?>')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

        <?php elseif ($view === 'create'): ?>
            <!-- Create View -->
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="mb-0">
                                <i class="fas fa-plus me-2"></i>Add New Record
                            </h4>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="index.php">
                                <input type="hidden" name="action" value="create">
                                
                                <div class="mb-3">
                                    <label for="name" class="form-label">Name *</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email *</label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Phone *</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" required>
                                </div>
                                
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <a href="index.php?view=list" class="btn btn-secondary me-md-2">
                                        <i class="fas fa-arrow-left me-1"></i>Cancel
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-1"></i>Save Record
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        <?php elseif ($view === 'edit' && $editRecord): ?>
            <!-- Edit View -->
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="mb-0">
                                <i class="fas fa-edit me-2"></i>Edit Record
                            </h4>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="index.php">
                                <input type="hidden" name="action" value="update">
                                <input type="hidden" name="id" value="<?= $editRecord['id'] ?>">
                                
                                <div class="mb-3">
                                    <label for="name" class="form-label">Name *</label>
                                    <input type="text" class="form-control" id="name" name="name" 
                                           value="<?= htmlspecialchars($editRecord['name']) ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email *</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?= htmlspecialchars($editRecord['email']) ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Phone *</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" 
                                           value="<?= htmlspecialchars($editRecord['phone']) ?>" required>
                                </div>
                                
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <a href="index.php?view=list" class="btn btn-secondary me-md-2">
                                        <i class="fas fa-arrow-left me-1"></i>Cancel
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-1"></i>Update Record
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete the record for <strong id="deleteName"></strong>?</p>
                    <p class="text-muted">This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" action="index.php" style="display: inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" id="deleteId">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i>Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/script.js"></script>
</body>
</html>
